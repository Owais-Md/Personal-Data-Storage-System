update department set mgr_ssn = "123456789" where dnumber = 5;
update employee set super_ssn = "123456789" where ssn = "123456789";
update employee set dno = 5 where ssn = "123456789";
update project set dnum = 5 where pnumber = 2;
