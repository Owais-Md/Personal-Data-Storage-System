insert into department values('Research', 5, NULL, '1988-05-22');
insert into employee values('John', 'B', 'Smith', '123456789', '1965-01-09', '731 Fondren, Houston, TX', 'M', 30000, NULL, NULL);
insert into dept_locations values(5, 'Sugarland');
insert into project values('ProductY', 2, 'Sugarland', NULL);
insert into works_on values('123456789', 2, 7.5);
insert into dependent values('123456789', 'Alice', 'F', '1986-04-05', 'Daughter');